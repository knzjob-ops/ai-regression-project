# AI Study Score Predictor

Proyek AI sederhana untuk memprediksi nilai siswa berdasarkan jam belajar menggunakan Linear Regression.
